let rowsCount = prompt("Please,set rows count .");

/**
 * Prints stars in each round equivalent to the round index .
 * * If rounds is null , throws an error .
 * @param rounds : Number of rows of printing .
 */
function printStars(rounds) {
  if (!rounds) throw new ReferenceError("The argument is invalid .");
  for (let round = 1; round <= rounds; round++) {
    let stars = "";
    for (let star = 1; star <= round; star++) {
      stars += "*";
    }
    console.log(stars);
  }
}

printStars(rowsCount);
