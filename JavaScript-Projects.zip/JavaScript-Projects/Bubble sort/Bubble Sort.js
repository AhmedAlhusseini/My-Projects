/**
 * Sorts an array items by comparison .
 * * If arr is undefined , throws an error .
 * @param arr : The array to sort .
 * @returns : The array with ascending sorted items .
 */
function bubbleSort(arr) {
  if (!arr) throw new ReferenceError("The argument is null .");
  for (let r = 0; r < arr.length; r++) {
    let swapped = false;
    for (let i = 0; i < arr.length - r - 1; i++) {
      if (arr[i] > arr[i + 1]) {
        [arr[i], arr[i + 1]] = [arr[i + 1], arr[i]];
        swapped = true;
      }
    }
    if (!swapped) return arr;
  }
}

let nums = [1, 3, 2, 8, 7, 9, 10, 6, 5, 4];

console.log("The array :", nums);
console.log("The array after sorting :", bubbleSort(nums));
