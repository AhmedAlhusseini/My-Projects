"use strict";

class Node {
  /**
   * Intializes the node .
   * @param data : The data of the created node .
   */
  constructor(data) {
    this.data = data;
    this.next = null;
  }
}

class LinkedList {
  /**
   * Initializes the linked list .
   */
  constructor() {
    this.head = null;
  }

  /**
   *  Adds a new node to the beginning of the linked list .
   * * If newData is null , throws an error .
   * @param newData : The data of the new node .
   */
  unShift(newData) {
    if (newData == undefined)
      throw new ReferenceError("The argument is null .");
    let newNode = new Node(newData);
    newNode.next = this.head;
    this.head = newNode;
  }

  /**
   * Adds a new node to the next position of the prev_node .
   * * If prevNode or newData is null , throws an error .
   * @param prevNode : The previous node .
   * @param newData : The new data of the new node .
   */
  splice(prevNode, newData) {
    if (prevNode == undefined || newData == undefined)
      throw new ReferenceError("The arguments are invalid .");
    let newNode = new Node(newData);
    newNode.next = prevNode.next;
    prevNode.next = newNode;
  }

  /**
   * Adds a new node to the end of the linked list .
   * * If newData is null , throws an error .
   * @param newData : The new data of the new node .
   */
  push(newData) {
    if (newData == undefined)
      throw new ReferenceError("The argument is null .");
    let item = this.head;
    let newNode = new Node(newData);
    if (!item) {
      this.head = newNode;
      return;
    }
    while (item.next) item = item.next;
    item.next = newNode;
  }

  /**
   * Deletes a node from the linked list .
   * * If key is null , throws an error .
   * @param key : The data of the wanted node .
   */
  deleteNode(key) {
    if (key == undefined) throw new ReferenceError("The argument is null .");
    let item = this.head;
    if (!item) throw new ReferenceError("It is not a linked list .");
    if (item.data == key) {
      this.head = item.next;
      item = undefined;
      return;
    }
    let prevItem = null;
    while (item) {
      if (item.data == key) {
        prevItem.next = item.next;
        item = undefined;
        return;
      }
      prevItem = item;
      item = item.next;
    }
    throw new ReferenceError(
      "The wanted node is not existed in the linked list ."
    );
  }

  /**
   * Prints all nodes in the linked list .
   */
  printList() {
    let item = this.head;
    if (!item) throw new ReferenceError("There is no linked list .");
    let nodes = "";
    while (item) {
      nodes += item.data + "-->";
      item = item.next;
    }
    console.log(nodes + null);
  }
}

let linkedList = new LinkedList();

let first = new Node(1);
let second = new Node(2);
let third = new Node(3);

linkedList.head = first;
first.next = second;
second.next = third;

linkedList.unShift(0);
linkedList.splice(second, 10);
linkedList.push(100);
linkedList.deleteNode(2);
linkedList.printList();
