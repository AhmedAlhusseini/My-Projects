let data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

/**
 * Reverses the array items order .
 ** If arr is undefined , throws an error .
 * @param arr : The array to reverse .
 * @returns : The array with reversed items .
 */
function reverse(arr) {
  if (!arr) throw new ReferenceError("The argument is null .");
  for (let i in arr) arr.splice(i, 0, arr.pop());
  return arr;
}

console.log("The array : ", data);
console.log("The array after reversing : ", reverse(data));
