/**
 * Checks out if the number is a prime or not .
 * * If num is null , throws an error .
 * @param num : A number to check out .
 * @returns : true if the number is a prime , else false .
 */
function isPrime(num) {
  if (!num) throw new ReferenceError("The argument is null .");
  if (num <= 1) return false;
  if (num <= 3) return true;
  if (num % 2 == 0 || num % 3 == 0) return false;
  let x = 5;
  while (x ** 2 <= num) {
    if (num % x == 0 || num % (x + 2) == 0) return false;
    x += 6;
  }
  return true;
}

/**
 * Makes an array of prime numbers .
 * * If maxNum is null , throws an error .
 * @param maxNum : The max number in the array .
 * @returns : An array contains all prime numbers including the max number "If it's a prime" .
 */
function primesArray(maxNum) {
  if (!maxNum) throw new ReferenceError("The argument is null .");
  let nums = [];
  for (let i = 2; i <= maxNum; i++) {
    if (isPrime(i)) nums.push(i);
  }
  return nums;
}

let answer = prompt(
  "Please , enter the max number of the prime numbers array = "
);
console.log("Here is the prime numbers array : ", primesArray(answer));
