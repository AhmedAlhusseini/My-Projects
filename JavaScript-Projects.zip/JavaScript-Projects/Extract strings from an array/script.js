let data = [1, 2, 3, "MO", 4, true, "AHMED", false, "SALAH", 5, 6, 7];

/**
 * Extracts strings from an array .
 * * If arr is undefined , throws an error .
 * @param arr : An array contains data .
 * @returns : A new array contains only strings .
 */
function filterNames(arr) {
  if (!arr) throw new ReferenceError("The argument is null .");
  var names = [];
  for (let item of arr) {
    if (typeof item == "string") names.push(item);
  }
  return names;
}

console.log(filterNames(data));
