"use strict";

// Dependencies .
const sqlite3 = require("sqlite3").verbose();

// Connection with the database .
const db = new sqlite3.Database("Blog.db", (err) => {
  if (err) return console.error(err.message);
  console.log("Connected with the DB .");
});

// Reading Query .
db.all(
  "SELECT Name , Content , ArticleName , Articles.Date FROM " +
    "Articles JOIN Comments ON Articles.ArticleID = Comments.ArticleID",

  (err, records) => {
    if (err) return console.error(err.message);
    console.log(records);
  }
);

// Interrupt the connection .
db.close((err) => {
  if (err) return console.error(err.message);
  console.log("The connection has been interrupted .");
});
