# Using SQLite3 database .
import sqlite3

# Making a connection with the database .
connection = sqlite3.connect("school.db")
cursor = connection.cursor()


def create_tables():
    """
    Creates students and lessons tables .
    """
    # Creating students' table .
    cursor.execute('''CREATE TABLE IF NOT EXISTS students(
                  student_id INTEGER PRIMARY KEY,
                  name TEXT, 
                  nickname TEXT, 
                  age INTEGER, 
                  grade TEXT, 
                  reg_date TEXT
                  );
                  ''')
    # Creating lessons table .
    cursor.execute('''CREATE TABLE IF NOT EXISTS lessons(
    lesson_id INTEGER PRIMARY KEY, 
    name TEXT,
    subscriber_id INTEGER,
    FOREIGN KEY (subscriber_id) REFERENCES students (student_id)
    );
    ''')
    # Writing changes .
    connection.commit()


def get_id() -> int:
    """
    Takes the student's id from the user .
    :return: The student's id .
    """
    answer = to_int(input("Enter the student's id: "))
    return answer


def find(_id: int) -> tuple:
    """
    Searches for the student in the students' table .
    :param _id: The id of the student .
    :return: A row contains student's information .
    """
    cursor.execute("SELECT * FROM students WHERE student_id=?;", (_id,))
    return cursor.fetchone()


def to_int(string: str) -> int:
    """
    Converts a string into an integer .
        *If the string contains non-numeric characters,
        it calls itself .
    :param string: A string contains numeric characters .
    :return: An integer from the numeric characters .
    """
    try:
        return int(string)
    except ValueError:
        print("This field must be an integer .")
        return to_int(input("Try again: "))


def form_head(header: str):
    """
    Prints the header of the forms .
    :param header: The name of the form .
    """
    print(f"{'-' * 20} {header} {'-' * 20}")


def form_tail():
    """
    Prints the footer of the forms .
    """
    print('-' * 64)


def add_student():
    """
    Adds a new student to the students' table,
    his lessons to the lessons table .
    """
    # Getting the student's information .
    form_head("Adding a new student")
    student_id = get_id()
    if find(student_id):
        print("This id is already existed!")
        return add_student()
    name = input("Enter the name of the student: ")
    nickname = input("Enter the nickname of the student: ")
    age = to_int(input("Enter the age of the student: "))
    grade = input("Enter the grade of the student: ")
    reg_date = input("Enter the registration date of the student: ")
    names = input("Enter the lessons names to subscribe of the student: ")
    form_tail()
    # Initializing the student's lessons .
    lessons = names.split(",")
    # Inserting the student's information into the students' table .
    cursor.execute('''INSERT INTO students 
        (student_id,name, nickname, age, grade, reg_date)
        VALUES (?, ?, ?, ?, ?, ?);''',
                   (student_id, name, nickname, age, grade, reg_date)
                   )
    # Inserting the student's lessons into the lessons table .
    for name in lessons:
        cursor.execute('''INSERT INTO lessons 
            (name,subscriber_id) VALUES (?, ?);''',
                       (name, student_id)
                       )
    # Writing changes .
    connection.commit()
    print()
    print("Student added successfully!")


def failed():
    """
    Prints the message of failing searching .
    """
    print("Student not found!")


def show_student():
    """
    Prints the student's information .
    """
    # Getting the student's information .
    student_id = get_id()
    student = find(student_id)
    if not student:
        failed()
    else:
        # Getting the student's lessons .
        cursor.execute('''SELECT lessons.name 
            FROM lessons JOIN students ON
            students.student_id = lessons.subscriber_id
            WHERE student_id = ? ;''',
                       (student_id,)
                       )
        result = cursor.fetchall()
        # Initializing the student's lessons .
        lessons = [x[0] for x in result]
        # Printing the student's information .
        print(f'''
            {'-' * 20} Student's Information {'-' * 20}
            id: {student[0]},
            name: {student[1]},
            nickname: {student[2]},
            age: {student[3]},
            grade: {student[4]},
            registration date: {student[5]},
            lessons: {lessons}
            {'-' * 64}
        ''')


def update_student():
    """
    Updates the student's information .
    """
    # Getting the student's id .
    student_id = get_id()
    if not find(student_id):
        failed()
    else:
        modify(student_id)


def modify(student_id: int):
    """
    Modifies the student's information .
    :param student_id: The id of the student .
    """
    # Getting the new information for the student .
    form_head("Updating the student's information")
    new_student_id = to_int(input("Enter the new id of the student: "))
    if new_student_id != student_id:
        if find(new_student_id):
            print("The new id is already existed!")
            return modify(student_id)
    name = input("Enter the new name of the student: ")
    nickname = input("Enter the new nickname of the student: ")
    age = to_int(input("Enter the new age of the student: "))
    grade = input("Enter the new grade of the student: ")
    reg_date = input("Enter the new registration date of the student: ")
    names = input("Enter the new lessons names to replace it with the old ones: ")
    form_tail()
    # Getting the old lessons for the student .
    cursor.execute('''SELECT lessons.name 
                FROM lessons JOIN students ON
                students.student_id = lessons.subscriber_id
                WHERE student_id = ?;''',
                   (student_id,)
                   )
    result = cursor.fetchall()
    # Initializing the old lessons for the student .
    old_lessons = [x[0] for x in result]
    # Initializing the new lessons for the student .
    new_lessons = names.split(",")
    # Updating the student's information in the students' table .
    cursor.execute('''UPDATE students 
                SET student_id=?, name=?, nickname=?, age=?, grade=?, reg_date=?
                WHERE student_id=?;''',
                   (new_student_id, name, nickname, age, grade, reg_date, student_id)
                   )
    # Updating the subscriber_id field in the lessons table .
    cursor.execute('''UPDATE lessons
                SET subscriber_id =?
                WHERE subscriber_id = ?;''',
                   (new_student_id, student_id)
                   )
    # Updating the lessons names for the student .
    index = 0
    for new_name in new_lessons:
        old_name = old_lessons[index]
        cursor.execute('''UPDATE lessons
                    SET name = replace(name,name,?) 
                    WHERE subscriber_id =? AND name = ?;''',
                       (new_name, new_student_id, old_name)
                       )
        index += 1
    # Writing changes .
    connection.commit()
    print()
    print("Student updated successfully!")


def delete_student():
    """
    Deletes the student from the students' table,
    and his lessons from lessons table .
    """
    # Getting the student's id .
    form_head("Deleting the student")
    student_id = get_id()
    form_tail()
    if not find(student_id):
        failed()
    else:
        # Deleting the lessons of the student from lessons table .
        cursor.execute("DELETE FROM lessons WHERE subscriber_id = ?;", (student_id,))
        # Deleting the student's information from the students' table .
        cursor.execute("DELETE FROM students WHERE student_id=?;", (student_id,))
        # Writing changes .
        connection.commit()
        print("Student deleted successfully!")


def connected() -> bool:
    """
    keeps the connection with the database .
    :return: True if continue , else False .
    """
    power = input("Click 'y' to continue or 'n' to terminate the session: ")
    if power == 'y':
        return True
    elif power == 'n':
        connection.close()
        return False
    else:
        print("Invalid choice!")
        return connected()


if __name__ == "__main__":
    create_tables()
    session = True
    while session:
        print('''
        Please choose the operation you want to perform:
        * To add a student, click on the letter a .
        * To delete a student, click on the letter d .
        * To modify a student’s information, click on the letter u .
        * To view student information, click on the letter s .
        ''')
        choice = input("Enter your choice: ")
        if choice == 'a':
            add_student()
        elif choice == 'd':
            delete_student()
        elif choice == 'u':
            update_student()
        elif choice == 's':
            show_student()
        else:
            print("Invalid choice!")
        session = connected()
