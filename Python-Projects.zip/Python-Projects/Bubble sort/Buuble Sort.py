def bubble_sort(arr: list) -> list:
    """
    Sorts a list items by comparison .
    :param arr: The list to sort .
    :return: The list with ascending sorted items .
    """
    for r in range(len(arr)):
        swapped = False
        for i in range(len(arr) - r - 1):
            if arr[i] > arr[i + 1]:
                arr[i], arr[i + 1] = arr[i + 1], arr[i]
                swapped = True
        if swapped is False:
            return arr


if __name__ == "__main__":
    nums = [7, 5, 8, 4, 22, 6, 0, 2]

    print(f'The list : {nums}')
    print(f'The list after sorting : {bubble_sort(nums)}')
