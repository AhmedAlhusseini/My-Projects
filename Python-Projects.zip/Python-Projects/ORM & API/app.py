# Global dependencies
from http.server import SimpleHTTPRequestHandler, HTTPServer
import json
from urllib.parse import urlparse, parse_qs
# Local dependencies
from database import DataBase
from models import Model
from fields import *

Model.DB = DataBase("socialApp.db")
Model.connection = Model.DB.connect()
PORT = 8000


class Users(Model):
    first_name = Varchar()
    last_name = Varchar()
    age = Integer()


class Posts(Model):
    title = Varchar()
    content = Text()
    created_at = Date()
    published = Boolean()


class Handler(SimpleHTTPRequestHandler):
    def do_GET(self):
        """
        Makes a GET request
        :return: A json file contains the requested data
        """
        # GET index.html or the project directory
        if self.path == "/":
            return SimpleHTTPRequestHandler.do_GET(self)
        # GET all users
        elif self.path == "/users":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(Users.all()).encode('utf-8'))
        # GET a specified user by his id
        else:
            user_id = int(self.path.split("/")[-1])
            result = Users.get(user_id)
            if result is False:
                self.send_response(404)
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                self.wfile.write(b'Sorry , the user is unfounded .')
                return
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(Users.get(user_id)).encode('utf-8'))

    def do_POST(self):
        """
        Makes a POST request to upload data
        """
        length = int(self.headers.get('Content-Length'))
        url = self.rfile.read(length)
        string = urlparse(url)
        query_string = parse_qs(string.path.decode('utf-8'))
        Users.create(first_name=query_string['first_name'][0], last_name=query_string['last_name'][0],
                     age=query_string['age'][0])
        self.send_response(301)
        self.send_header("Location", "localhost:8000")
        self.end_headers()


if __name__ == "__main__":
    with HTTPServer(("", PORT), Handler) as httpd:
        print(f'Server is working at {PORT} .')
        httpd.serve_forever()
