class Model:
    DB = None
    connection = None

    def __init__(self):
        """
        Initializes the table
        """
        self._create_table()
        self._saved = False

    @classmethod
    def _get_table_name(cls):
        """
        Shows the name of the current model
        :return: Table name
        """
        return cls.__name__.lower()

    @classmethod
    def get_columns(cls):
        """
        Shows fields and its datatypes of the model
        :return: Table columns
        """
        columns = {}
        for key, value in cls.__dict__.items():
            if str(key).startswith("_"):
                continue
            columns[str(key)] = str(value)
        return columns

    def _create_table(self):
        """
        Creates a table in the database
        :return: The executed SQL
        """
        columns = ",".join(" ".join((key, value)) for key, value in self.get_columns().items())
        sql = f"CREATE TABLE IF NOT EXISTS {self._get_table_name()}( id INTEGER PRIMARY KEY , {columns})"
        cursor = self.connection.cursor()
        result = cursor.execute(sql)
        return result

    @classmethod
    def all(cls):
        """
        Brings all table records
        :return: A list contains records as dictionaries
        """
        sql = f'SELECT * FROM {cls._get_table_name()}'
        records = cls.connection.execute(sql)
        return [dict(row) for row in records.fetchall()]

    @classmethod
    def get(cls, _id):
        """
        Brings a specified record
        :param _id: The primary key
        :return: The record as a dictionary
        """
        sql = f'SELECT * FROM {cls._get_table_name()} WHERE ID = ?'
        records = cls.connection.execute(sql, (_id,))
        result = records.fetchone()
        if result is None:
            return False
        return dict(result)

    @classmethod
    def find(cls, col_name, value):
        """
        Brings a specified records
        :param col_name: The field name in the table
        :param value: The keyword for searching
        :return: A list contains records as dictionaries
        """
        sql = f'SELECT * FROM {cls._get_table_name()} WHERE {col_name} LIKE "%{value}%"'
        records = cls.connection.execute(sql)
        return [dict(row) for row in records.fetchall()]

    @classmethod
    def create(cls, **kwargs):
        """
        Imports fields & records from  query string
        :param kwargs: A dictionary contains posted data
        """
        fields = list(kwargs.keys())
        values = [f'"{value}"' for value in kwargs.values()]
        cls._insert(fields, values)

    @classmethod
    def _insert(cls, fields, values):
        """
        Inserts new data into the table
        :param fields: The columns in the table
        :param values: The records of these columns
        :return: The executed SQL
        """
        sql = f'INSERT INTO {cls._get_table_name()} ({" , ".join(fields)}) VALUES ({" , ".join(values)})'
        result = cls.connection.execute(sql)
        cls.connection.commit()
        cls._saved = True
        return result
