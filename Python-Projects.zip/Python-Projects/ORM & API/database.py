import sqlite3


class DataBase:
    def __init__(self, path):
        """
        Initializes the Database
        :param path: The file path
        """
        self.path = path
        self.connection = None
        self.connected = False
        self.connect()

    def connect(self):
        """
        Opens a connection to the Database & enable data manipulation
        :return: Connection object
        """
        try:
            self.connection = sqlite3.connect(self.path)
            self.connection.row_factory = sqlite3.Row
            self.connected = True
        except sqlite3.Error as e:
            print(e)
        return self.connection

    def commit(self):
        """
        allows CUD operations
        """
        self.connection.commit()

    def close(self):
        """
        Closes the connection
        """
        if self.connected:
            self.connection.close()
        self.connected = False
