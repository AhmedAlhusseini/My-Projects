def is_prime(num: int) -> bool:
    """
    Checks out if the number is a prime or not .
    :param num:  A number to check out .
    :return: True if the number is a prime , else False .
    """
    if num <= 1:
        return False
    if num <= 3:
        return True
    if num % 2 == 0 or num % 3 == 0:
        return False
    x = 5
    while x ** 2 <= num:
        if num % x == 0 or num % (x + 2) == 0:
            return False
        x += 6
    return True


def primes_list(max_num) -> list[int]:
    """
    Makes a list of prime numbers .
    :param max_num: The max number in the list .
    :return: A list contains all prime numbers including the max number "If it's a prime" .
    """
    l_num = int(max_num)
    nums = [i for i in range(2, l_num + 1) if is_prime(i)]
    return nums


if __name__ == "__main__":
    answer = input("Please , enter the max number of the prime numbers list = ")
    print(f'Here is the prime numbers list : {primes_list(answer)}')
