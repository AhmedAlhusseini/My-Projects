class Node:
    def __init__(self, data):
        """
        Initializes the node .
        :param data: The data of the created node .
        """
        self.data = data
        self.next = None


class LinkedList:
    def __init__(self):
        """
        Initializes the linked list .
        """
        self.head = None

    def un_shift(self, new_data):
        """
        Adds a new node to the beginning of the linked list .
        :param new_data: The data of the new node .
        """
        new_node = Node(new_data)
        new_node.next = self.head
        self.head = new_node

    @staticmethod
    def insert(prev_node, new_data):
        """
        Adds a new node to the next position of the prev_node .
        :param prev_node: The previous node .
        :param new_data: The new data of the new node .
        """
        if prev_node is None:
            raise ValueError("The previous node is not existed in the linked list .")
        new_node = Node(new_data)
        new_node.next = prev_node.next
        prev_node.next = new_node

    def append(self, new_data):
        """
        Adds a new node to the end of the linked list .
        :param new_data: The new data of the new node .
        """
        item = self.head
        new_node = Node(new_data)
        if item is None:
            self.head = new_node
            return
        while item.next:
            item = item.next
        item.next = new_node

    def delete_node(self, key):
        """
        Deletes a node from the linked list .
        :param key: The data of the wanted node .
        """
        item = self.head
        if item is None:
            raise ValueError("It is not a linked list .")
        if item.data == key:
            self.head = item.next
            del item
            return
        prev_item = None
        while item:
            if item.data == key:
                prev_item.next = item.next
                del item
                return
            prev_item = item
            item = item.next
        raise ValueError("The wanted node is not existed in the linked list .")

    def print_list(self):
        """
        Prints all nodes in the linked list .
        """
        item = self.head
        if item is None:
            raise ValueError("It is not a linked list .")
        while item:
            print(item.data, end="-->")
            item = item.next
        print(None)


if __name__ == "__main__":
    linked_list = LinkedList()

    first = Node(1)
    second = Node(2)
    third = Node(3)

    linked_list.head = first
    first.next = second
    second.next = third

    linked_list.un_shift(0)
    linked_list.insert(second, 10)
    linked_list.append(100)
    linked_list.delete_node(2)

    linked_list.print_list()
